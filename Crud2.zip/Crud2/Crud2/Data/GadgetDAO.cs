﻿using Crud2.Models;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Crud2.Data

{
    internal class GadgetDAO
    {
        private string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=BondGadgetDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        //perform all operations on the db. get all, create, delete, get one, search etc.
        public GadgetModel FetchOne(int Id)
        {
            GadgetModel gadget = new GadgetModel();
            //access the db
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                string sqlQuery = "Select ID,Name,Description,AppearsIn,WithThisActor from dbo.Gadgets WHERE Id=@id";
                SqlCommand command = new SqlCommand(sqlQuery, connection);
                command.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = Id;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        gadget.Id = reader.GetInt32(0);
                        gadget.Name = reader.IsDBNull(1) ? "" : reader.GetString(1);
                        gadget.Description = reader.IsDBNull(2) ? "" : reader.GetString(2);
                        gadget.AppearsIn = reader.IsDBNull(3) ? "" : reader.GetString(3);
                        gadget.WithThisActor = reader.IsDBNull(4) ? "" : reader.GetString(4);

                    }
                }

            }
            return gadget;
        }
        public List<GadgetModel> FetchAll()
        {
            List<GadgetModel> gadgets = new List<GadgetModel>();
            //access the db
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                string sqlQuery = "Select ID,Name,Description,AppearsIn,WithThisActor from dbo.Gadgets";
                SqlCommand command = new SqlCommand(sqlQuery, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        GadgetModel gadget = new GadgetModel();
                        gadget.Id = reader.GetInt32(0);
                        gadget.Name = reader.IsDBNull(1) ? "" : reader.GetString(1);
                        gadget.Description = reader.IsDBNull(2) ? "" : reader.GetString(2);
                        gadget.AppearsIn = reader.IsDBNull(3) ? "" : reader.GetString(3);
                        gadget.WithThisActor = reader.IsDBNull(4) ? "" : reader.GetString(4);
                        gadgets.Add(gadget);
                    }
                }

            }
            return gadgets;
        }

        //create new
        public int Create(GadgetModel gadgetModel)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sqlQuery = "INSERT INTO dbo.Gadgets Values(@Name,@Description,@AppearsIn,@WithThisActor)";                
                SqlCommand command = new SqlCommand(sqlQuery, connection);
                command.Parameters.Add("@Name", System.Data.SqlDbType.VarChar,1000).Value = gadgetModel.Name;
                command.Parameters.Add("@Description", System.Data.SqlDbType.VarChar, 1000).Value = gadgetModel.Description;
                command.Parameters.Add("@AppearsIn", System.Data.SqlDbType.VarChar, 1000).Value = gadgetModel.AppearsIn;
                command.Parameters.Add("@WithThisActor", System.Data.SqlDbType.VarChar, 1000).Value = gadgetModel.WithThisActor;

                connection.Open();
                int newID = command.ExecuteNonQuery();

                return newID;
            }
        }
        public int Edit(GadgetModel gadgetModel,int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
               
                
                string sqlQuery = @"UPDATE dbo.Gadgets SET Name = @Name, Description = @Description, AppearsIn = @AppearsIn, WithThisActor = @WithThisActor OUTPUT INSERTED.Id WHERE Id = @id";
                SqlCommand command = new SqlCommand(sqlQuery, connection);
                command.Parameters.AddWithValue("@Id", id);
                command.Parameters.AddWithValue("@Name", gadgetModel.Name);
                command.Parameters.AddWithValue("@Description", gadgetModel.Description);
                command.Parameters.AddWithValue("@AppearsIn", gadgetModel.AppearsIn);
                command.Parameters.AddWithValue("@WithThisActor", gadgetModel.WithThisActor);
                connection.Open();
                
                int updatedID = (int)command.ExecuteScalar();
                return updatedID;
            }
        }

        public int Delete( int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {


                string sqlQuery = @"DELETE FROM dbo.Gadgets WHERE Id = @id;";
                SqlCommand command = new SqlCommand(sqlQuery, connection);
                command.Parameters.AddWithValue("@Id", id);
                connection.Open();

                int updatedID = (int)command.ExecuteNonQuery();
                if (updatedID == 0)
                {
                    return 0;
                }else
                {
                    return id;
                }
                
            }
        }

    }
}