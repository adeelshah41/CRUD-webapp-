﻿using Crud2.Data;
using Crud2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Crud2.Controllers
{
    public class GadgetsController : Controller
    {
        // GET: Gadgets
        public ActionResult Index()
        {
            List<GadgetModel> gadgets = new List<GadgetModel>();
            GadgetDAO gadgetDAO = new GadgetDAO();
            gadgets =gadgetDAO.FetchAll();



            return View("Index",gadgets);
        }
        public ActionResult Details(int id)
        {
            GadgetDAO gadgetDAO = new GadgetDAO();
            GadgetModel gadget =gadgetDAO.FetchOne(id);
            return View("Details", gadget);
        }
        public ActionResult Create()
        {
            return View("GadgetForm");
        }
        public ActionResult ProcessCreate(GadgetModel gadgetModel)
        {
            //save to the database
            GadgetDAO gadgetDAO = new GadgetDAO();
            gadgetDAO.Create(gadgetModel);
            return View("Details", gadgetModel);
        }
        public ActionResult Edit(int id)
        {
            GadgetDAO gadgetDAO = new GadgetDAO();
            GadgetModel gadget = gadgetDAO.FetchOne(id);
            return View("GadgetForm2",gadget); //WORKS 
        }
        public ActionResult ProcessEdit(GadgetModel gadgetModel)
        {
            //save to the database
            GadgetDAO gadgetDAO = new GadgetDAO();
            gadgetDAO.Edit(gadgetModel,gadgetModel.Id);
            return View("Details", gadgetModel);
        }
        public ActionResult Delete(int id)
        {
            //delete from the database
            GadgetDAO gadgetDAO = new GadgetDAO();
            int result;
              result = gadgetDAO.Delete(id);

            List<GadgetModel> gadgets = new List<GadgetModel>();
            GadgetDAO gadgetDAO1 = new GadgetDAO();
            gadgets = gadgetDAO1.FetchAll();

            return View("Index",gadgets);
        }

    }
}